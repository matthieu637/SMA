package jason.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public interface ToDOM {
    public Element getAsDOM(Document document);
}
