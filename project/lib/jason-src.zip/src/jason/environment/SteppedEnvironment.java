package jason.environment;

/**
 * @deprecated this class was renamed to TimeSteppedEnvironment 
 */
public class SteppedEnvironment extends TimeSteppedEnvironment {
}
